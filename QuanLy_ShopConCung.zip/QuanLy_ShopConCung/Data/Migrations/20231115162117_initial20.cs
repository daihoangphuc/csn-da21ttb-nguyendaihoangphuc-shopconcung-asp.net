﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace QuanLy_ShopConCung.Data.Migrations
{
    public partial class initial20 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
